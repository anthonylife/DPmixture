base = [pwd '/'];
addpath([base 'dpmix']);
addpath([base 'datasets']);
addpath([base 'utilities']);
