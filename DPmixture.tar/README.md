DPmixture
=========

Dirichlet Process Mixture Model (using CRP to inference)